<?php $title = ""; 

if(is_day()):
	$title = "You are viewing the " . get_the_date() . " daily archives";
elseif(is_month()):
	$title = "You are viewing the " . get_the_date("F Y") . " monthly archives";
elseif(is_year()):
	$title = "You are viewing the " . get_the_date("Y") . " yearly archives";	
elseif(is_author()):
	$title = "You are viewing the author archives";
else:
	$title = "You are viewing the " . single_cat_archives("", false) . " archives";

?>

<?php get_header(); ?>
	<div class="container blog-content">

		<?php if (have_posts()) : while (have_posts()) : the_post(); ?>

		<div <?php post_class(); ?> id="post-<?php the_ID(); ?>">
			<div class="col-lg-8">
				
					<h2><?php echo $title ?></h2>
					
					<?php the_content(); ?>

					<div class="postmetadata">
						<?php the_tags('Tags: ', ', ', '<br />'); ?>
						Posted in <?php the_category(', ') ?> | 
						<?php comments_popup_link('No Comments &#187;', '1 Comment &#187;', '% Comments &#187;'); ?>
						
					</div><br>
				
			</div>

		</div>
	
		<?php endwhile; ?>


		<?php else : ?>

			<h2>Not Found</h2>

		<?php endif; ?>
			
			<?php get_sidebar("right"); ?>
		 
	</div><!--end container-->
<?php get_footer(); ?>