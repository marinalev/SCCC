<?php get_header(); ?>
	<div class="container blog-content">
	<div id="right-sidebar"><?php get_sidebar("right"); ?></div>
		<?php if (have_posts()) : while (have_posts()) : the_post(); ?>

		<div <?php post_class(); ?> id="post-<?php the_ID(); ?>">
			<div class="col-lg-7 col-md-7	">
				
					<h2><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></h2>
					
					<?php the_content(); ?>

					<div class="postmetadata">
						<?php the_tags('Tags: ', ', ', '<br />'); ?>
						Posted in <?php the_category(', ') ?> | 
						<?php comments_popup_link('No Comments &#187;', '1 Comment &#187;', '% Comments &#187;'); ?>
						
					</div><br>
				
			</div>
				
		</div>
	
		<?php endwhile; else : ?>

			<h2>Not Found</h2>

		<?php endif; ?>
			
			
		
	</div><!--end container-->
<?php get_footer(); ?>