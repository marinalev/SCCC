<?php get_header(); ?>
<div class="container">
	<div class="col-lg-8">
		<h2>Sorry, page not found.</h2>
		
		<br>

	</div>
	<div class="col-lg-4">
		<?php get_sidebar("right"); ?>
	</div>
</div>
<?php get_footer(); ?>