<?php

//sidebars
register_sidebar(array(
	"name" => "Right Side Bar",
	"id" => "right-sidebar",
	"description" => "Right Side Bar",
	"before_widget" => "<div  id='widget'>",
	"after_widget" => "</div><br > <br> <!--end widget-->", 
	"before_title" => "<h3 class='widget_title'>",
	"after_title" => "</h3>"
));

register_sidebar(array(
	"name" => "Left Side Bar",
	"id" => "left-sidebar",
	"description" => "Left Side Bar",
	"before_widget" => "<div  id='widget' style=float: 'right'>",
	"after_widget" => "</div><br > <br> <!--end widget-->", 
	"before_title" => "<h3 class='widget_title'>",
	"after_title" => "</h3>"
));

//wp admin bar in dashboard

show_admin_bar(false);


//menus

register_nav_menus(array(
	"main_menu"=>"Main Navigation",
	"resources_menu"=>"Resources Menu in sidebar	",
	"member_menu"=>"Member Menu"
));



	$resourcesMenu = array(
		"theme_location" => "resources_menu",
		"container" => "<nav>",
		"container_class" => "",
		"container_id" => "resources_menu",
		"depth" => 1	
	);



//custom login
function my_login_logo() { ?>
    <style type="text/css">
        body.login div#login h1 a {
            background-image: url(<?php echo get_stylesheet_directory_uri(); ?>/img/small-logo.png);
            padding-bottom: 0px;
			width: 300px;
			background-size: 300px;
			
        }
		.wp-core-ui .button-primary {
			background: #009933;
			background-border: green;
		}
    </style>
<?php }
add_action( 'login_enqueue_scripts', 'my_login_logo' );

function my_login_logo_url() {
    return home_url();
}
add_filter( 'login_headerurl', 'my_login_logo_url' );

function my_login_logo_url_title() {
    return 'Your Site Name and Info';
}
add_filter( 'login_headertitle', 'my_login_logo_url_title' );

function my_login_stylesheet() {
    wp_enqueue_style( 'custom-login', get_template_directory_uri() . '/style-login.css' );
    wp_enqueue_script( 'custom-login', get_template_directory_uri() . '/style-login.js' );
}
add_action( 'login_enqueue_scripts', 'my_login_stylesheet' );


?>