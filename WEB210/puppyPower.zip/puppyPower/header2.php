<!DOCTYPE html>
<html <?php language_attributes(); ?>>
  <head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="PuppyPower 4-H">
    <link rel="shortcut icon" href="<?php bloginfo('template_url');?>/ico/favicon.png">

    <title><?php bloginfo("name") . wp_title(' |'); ?></title>	
	<!--[if lt IE 9]>
		<script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
	<![endif]-->

    <!-- Bootstrap core CSS -->
    <link href="<?php bloginfo('template_url');?>/css/bootstrap.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link rel="stylesheet" href="<?php bloginfo('stylesheet_url'); ?>">
    <link rel="stylesheet" href="<?php bloginfo('template_url');?>/css/icomoon.css">
    <link href="<?php bloginfo('template_url');?>/css/animate-custom.css" rel="stylesheet">

    
    <link href='http://fonts.googleapis.com/css?family=Lato:300,400,700,300italic,400italic' rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Roboto:400,300,700,300italic,400italic|Roboto+Condensed:400,300|Roboto+Slab:400,700,300' rel='stylesheet' type='text/css'>
   <link href='http://fonts.googleapis.com/css?family=Bree+Serif' rel='stylesheet' type='text/css'>
  
	<script type="text/javascript" src="<?php bloginfo('template_url');?>/js/modernizr.custom.js"></script>
    
    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="<?php bloginfo('template_url');?>/js/html5shiv.js"></script>
      <script src="<?php bloginfo('template_url');?>/js/respond.min.js"></script>
    <![endif]-->
	<?php wp_enqueue_script( 'jquery' ); ?>
	<?php wp_head(); ?>
  </head>

  <body data-spy="scroll" data-offset="0" data-target="#navbar-main">
  
  
  	<div id="navbar-main">
      <!-- Fixed navbar -->
    <div class="navbar  navbar-static-top hidden-xs">
      <div class="container">
        <div class="navbar-header">
         <a class="navbar-brand hidden-xs smoothScroll" href="<?php bloginfo('url');?>/#home"><img id="top-logo"  src="<?php bloginfo('template_url');?>/img/new-top-logo.png"></a>
        </div>
		<div class="row">
		<div class="container">
			<div class="top-nav pull-right">
				<?php if (is_user_logged_in()) { ?>
				<!-- User is logged in: show Admin and Log out link -->
				
				<a href="<?php echo wp_logout_url( 'http://puppypowerwp.azurewebsites.net' ); ?>">Log out</a>
				
				<?php } else { ?>
					<!-- User is logged out: show Log in link -->
					<a href="<?php echo wp_login_url( 'http://www.tiffanysevareid.com/dev-puppypower/members/' ); ?> "class="simplemodal-login" >LOG IN</a>
					
				<?php } ?>

			</div><!--end top-nav-->
		</div>	<!--end container-->
		</div><!--end row-->
				<!--<div class="navbar-collapse collapse">
				  <ul class="nav navbar-nav">
					<li> <a href="<?php //bloginfo('url');?>/members" data-toggle="collapse" data-target=".navbar-ex1-collapse"> Member Area</a></li>
					<li> <a href="<?php //bloginfo('url');?>/events" data-toggle="collapse" data-target=".navbar-ex1-collapse"> Events</a></li>
					<li> <a href="<?php //bloginfo('url');?>/blog" data-toggle="collapse" data-target=".navbar-ex1-collapse"> Blog</a></li>-->
					
				  </ul>
				</div><!--/.nav-collapse -->
      </div><!--end container-->
    </div><!--end navbar-->
    </div><!--end navbar-main-->
	
	
	<!---mobile nav-->
	
	<nav class="navbar-default navbar-fixed-top row visible-xs" role="navigation" id="navigation"> 
		  <!-- Brand and toggle get grouped for better mobile display -->
		  <div class="navbar-header">
		     <a href="#"><img class="" id="top-logo-mobile"  src="<?php bloginfo('template_url');?>/img/new-top-logo.png"></a>
		  
			<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
			  <span class="sr-only">Toggle navigation</span>
			  <span class="icon-bar"></span>
			  <span class="icon-bar"></span>
			  <span class="icon-bar"></span>
			</button>
		  </div>
		  <!-- Collect the nav links, forms, and other content for toggling -->
		  <div class="container">
		  <div class="collapse navbar-collapse navbar-ex1-collapse">
			<ul class="nav navbar-nav" id="navigation-items">
				<li> <a href="<?php bloginfo('url');?>/members" class="smoothScroll"> Member Area</a></li>
               <li><a href="<?php bloginfo('url');?>/events">Events</a></li>
			   <li><?php if (is_user_logged_in()) { ?>
					<a href="<?php echo wp_logout_url( WP_HOME ); ?>">Log out</a>
    			<?php } else { ?>
					<a href="<?php echo wp_login_url( 'http://www.tiffanysevareid.com/dev-puppypower/members/' ); ?> "class="simplemodal-login" >LOG IN</a>
				<?php } ?></li>
			</ul>
			</div>
		 </div><!-- /.navbar-collapse -->
	</nav>
 