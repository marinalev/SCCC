<?php get_header(); ?>

 
  
		<!-- ==== HEADERWRAP ==== -->
	    <div id="headerwrap" class="img-responsive" id="home" name="home">
			<!--<header class="clearfix">
	  		 		
	  		</header>	-->   

		<!-- <h1>Empowering Youth & Families</h1> -->			
	    </div><!-- /headerwrap -->
		<div id="tagline" class="container"><h1>Raising puppies,<br>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Changing lives</h1></div>
       
		<!-- ==== BANNER ===== -->
		<!--<div class="container" id="banner" name="banner">
			<div class="row">
				<h2>Puppy Power<br> 
				Assistance Dog Project</h2>
				<p class="tagline">The Gift of Independence</p>
			</div><!--end row-->
		<!--</div><!--end container-->
		
		<!-- ==== ABOUT ==== -->
		<div class="container" id="about" name="about">
			<div class="row white">
			<br>
				<h1 class="centered">ABOUT US</h1>
				
				<div id="logo-original"><img class="img-responsive col-sm-3 col-md-3 col-lg-2 col-sm-offset-0 col-md-offset-0 col-lg-offset-2 " src="<?php bloginfo('template_url');?>/img/PuppyPowerLogo.gif"></div>
								
				 <div class="col-sm-9 col-md-9 col-lg-6">
					<p>Puppy Power 4-H is a unique 4-H group whose members either raise and train assistance puppies, or have an assistant dog as a 4-H project. The club brings together youth of all ages and abilities with their assistance dogs or assistance puppies in training to work together, grow, learn, and achieve skills in all aspects of their lives where they truly make a difference to those around them.</p>
				</div><!-- col-lg-offset-2 col-lg-8 -->
				
				
			</div><!-- row -->
		</div><!-- container -->
		
		<!-- ==== greenwrap ==== -->
		<div id="greenwrap">
			<div id="testimonials">	
				<div class="row">
				
					<h1 class="centered">TESTIMONIALS</h1>
					
                    <div class="container">
                    
                    <blockquote class="col-lg-4">"I remember when I had a misbehaving dog and it was very tough on me and puppy power helped me get through it." <br><br>
					- <strong>Dana Sterritt</strong>, Member</blockquote>
					
                      <blockquote class="col-lg-4">"Puppy Power and 4-H has led us to positive experiences that my kids and I would have not even thought of."<br><br>
					  - <strong>Ellie Osburn</strong>, Parent</blockquote>
                    
                      <blockquote class="col-lg-4">"Where can you see 20 puppies under 18 months old all being raised by children sitting in a row on command?  At Puppy Power 4H Service Dog Project class!"<br><br>
					  - <strong>Barb Lock</strong>, Parent</blockquote>
                    
		</div>
			</div><!-- row -->
				
				
				
			</div><!-- container -->
	
		</div><!-- wrap -->
		
		<!-- ==== Get Involved ==== -->
		<div id="get-involved" name="get-involved">
		<br>
		<div class="container" >
			
			<div class="row white">
				<h1 class="centered">GET INVOLVED</h1>
				
				<br>
				<!-- ==== WHITEWRAP ==== -->
				<div id="whitewrap">
					<div class="row white">
						<div class="col-lg-4 callout">
							<span class="icon icon-heart"></span>
							<h2>Join</h2>
							<p>Raise a puppy for 18 months and give the gift of joy!  4-H youth learn life skills and the value of service while having fun!<br>
							<a id="modal" data-target="#myModal" data-toggle="modal"> Learn more</a></p>
							<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
							  <div class="modal-dialog">
								<div class="modal-content">
								  <div class="modal-header">
									<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
									<h4 class="modal-title" id="myModalLabel">Join Puppy Power</h4>
								  </div>
								  <div class="modal-body">
									<p>Our club project is raising service dogs for Canine Companions for Independence, not training family dogs to become a service dog. (Please contact the 4H extension office for information about other clubs in your area.)   </p>	
								  </div>
								  <div class="modal-footer">
									<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
								  </div>
								</div>
							  </div>
							</div>
						</div><!-- col-lg-4 -->
							
						<div class="col-lg-4 callout">
							<span class="icon icon-users"></span>
							<h2>Volunteer</h2>
							<p>Support local youth by volunteering your time.  Make a difference today!</p>
						</div><!-- col-lg-4 -->	
						
						<div class="col-lg-4 callout">
							<span class="icon icon-gift"></span>
							<h2>Donate</h2>
							<p><a href="http://puppypowerwp.azurewebsites.net/donate/">Your gift</a> enables us to continue making a positive impact on youth and families. Personal donations and company matches are tax deductible. Thank you! </p>
						</div><!-- col-lg-4 -->	
					</div><!-- row -->
				</div><!-- whitewrap -->
			</div><!-- row -->
		</div><!-- container -->
		</div><!--get-involved-->
		
		<div id="greenwrap2">
			<div id="feature">
				<div class="row">
				<h1 class="centered">JORDAN'S STORY</h1>
					<div class="container">
					<div id="book"><img class="col-sm-3 col-md-3 col-lg-2 col-lg-offset-2 img-responsive img-thumb" src="<?php bloginfo('template_url');?>/img/jordanbook.jpg"></div>
						<div class="col-sm-9 col-md-9 col-lg-6">
							<p>Jordan was born with a rare chromosome abnormality that has left her unable to talk, walk and eat. She is able to communicate through head movements and through her iPad. She is blessed to have an amazing service dog, Baker, that is part of every thing she does in the book and in life. This book is their first adventure mystery. But, knowing Jordan and Rachelle, the first of many!</p>
							<p>Proceeds from the sale of Mystery At The Horse Show will be donated to the Jordan Fund, a nonprofit organization that provides support to the families of children with special needs.</p>
							<a href="http://giddyupgirlsbooks.com/" target="_blank">Learn more at Giddy Up Girls Books</a>
							</div>
					</div>
				</div><!-- row -->
			</div><!-- container -->
		</div><!-- wrap -->	
		
 
		<div id="contact" name="contact">

		<div id="greywrap">
		<div class="container" id="contact" name="contact">
			<div class="row">
			<br>
				<h1 class="centered">CONTACT US</h1>
				
				<br>
				<br>
				<div class="col-lg-offset-2 col-lg-4 contact-right">
					<h3>Mailing Address</h3>
				
					<p>Puppy Power<br/>
					  17231 11 Ave NE<br/>
					  Shoreline, WA 98155-5111 <br/>
					</p>
				</div><!-- col -->
				
				<div class="col-lg-4 contact-left">
					<h3>Leadership Team</h3>
				
					<p class=""><strong>Leslie Anderson, Club Leader</strong><br>
					leslie-mm-anderson@hotmail.com<br>
					(206) 361-9113</p>
					
					<p><strong>Brent Anderson, Assistant Club Leader</strong><br>
					brent.4h@outlook.com<br>
					(206) 327-3333</p>
					
					<p><strong>Terri Smith
					 Project Leader</strong><br>
					auntiered@frontier.com<br>
					</p>
					
				</div><!-- col -->

			</div><!-- row -->
		
		</div><!-- container -->
		</div><!--wrap-->
		</div><!--contact-->

		
		
		<!-- ==== TEAM MEMBERS ==== -->
		<div >
		<div class="container" id="partners" name="partners">
			<div class="row white centered affiliates">
				<div class="col-sm-4 col-md-4 col-lg-4 centered">
					 <a href="http://www.cci.org" target="_blank">
					 <img class="img" src="<?php bloginfo('template_url');?>/img/CCI_colorlogo.jpg" height="120px"  alt="">
					</a>
				</div><!-- CCI -->
				
				
				<div class="col-sm-4 col-md-4 col-lg-4 centered">
					<a href="http://www.4-h.org/" target="_blank">
					<img class="img" src="<?php bloginfo('template_url');?>/img/4H-clover-color.png" height="120px"  alt="">
					</a>
					
				</div><!-- 4H -->
				
				
				<div class="col-sm-4 col-md-4 col-lg-4 centered">
					<a href="http://ext100.wsu.edu/snohomish/4h/" target="_blank">
					<img class="img" src="<?php bloginfo('template_url');?>/img/wsu-logo.png" height="120px"  alt="">
					</a>
				</div><!-- WSU -->
				
				
				
				
				
				
			</div><!-- row -->
		</div><!-- container -->
		</div><!--green-->

		
<?php get_footer(); ?>