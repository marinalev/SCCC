<div id="footerwrap">
			<div class="container">
				<footer class="row col-lg-12  ">
					<p class="center">&copy; 2014 Puppy Power | 
						<a href="<?php bloginfo('url');?>/members/">Member Area</a> | 	<a href="<?php bloginfo('url');?>/wp-admin">Admin</a></p>
				</footer>
				<br />
				
			</div><!--end container-->
</div>

    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
		

	<script type="text/javascript" src="<?php bloginfo('template_url');?>/js/bootstrap.min.js"></script>
	<script type="text/javascript" src="<?php bloginfo('template_url');?>/js/retina.js"></script>
	<script type="text/javascript" src="<?php bloginfo('template_url');?>/js/jquery.easing.1.3.js"></script>
    <script type="text/javascript" src="<?php bloginfo('template_url');?>/js/smoothscroll.js"></script>
	<script type="text/javascript" src="<?php bloginfo('template_url');?>/js/jquery-func.js"></script>
		
  </body>
</html>