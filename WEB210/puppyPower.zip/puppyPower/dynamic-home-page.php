<?php 
/* 
 * Template Name: Dynamic Home Page
 */
?>
 
<?php get_header(); ?>
		
		<!-- ==== ABOUT ==== -->
		<div class="container" id="about" name="about">
			<div class="row white">
			<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
				<!--<h1 class="centered"><?php //the_title();?></h1>-->
				<div id="logo-original"><img class="img-responsive col-sm-3 col-md-3 col-lg-2 col-sm-offset-0 col-md-offset-0 col-lg-offset-2 " src="<?php bloginfo('template_url');?>/img/PuppyPowerLogo.gif"></div>
				<div class="col-sm-9 col-md-9 col-lg-6">
				<?php the_post_thumbnail();?>
				<?php the_content(); ?>
				</div>
			<?php endwhile; else: ?>
				<p>Sorry we couldn't find your post</p>
			<?php endif; ?>
			</div><!--end row white-->
		</div><!--end container-->
			
		
			<div id="greenwrap">
				<div id="testimonials">	
					<div class="row">
					<?php the_block("Testimonials"); ?>	
					</div> 
				</div><!--end testimonials-->
			</div><!--end greenwrap-->
		   
				<!-- ==== Get Involved ==== -->
		<div id="get-involved" name="get-involved">
		<br>
		<div class="container" >
			
			<div class="row white">
				<h1 class="centered">GET INVOLVED</h1>
				
				<br>
				<!-- ==== WHITEWRAP ==== -->
				<div id="whitewrap">
					<div class="row white">
						<div class="col-lg-4 callout">
							<span class="icon icon-heart"></span>
							<h2>Join</h2>
							<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.<br>
							<a id="modal" data-target="#myModal" data-toggle="modal"> Learn more</a></p>
							<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
							  <div class="modal-dialog">
								<div class="modal-content">
								  <div class="modal-header">
									<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
									<h4 class="modal-title" id="myModalLabel">Join Puppy Power</h4>
								  </div>
								  <div class="modal-body">
									...
								  </div>
								  <div class="modal-footer">
									<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
								  </div>
								</div>
							  </div>
							</div>
						</div><!-- col-lg-4 -->
							
						<div class="col-lg-4 callout">
							<span class="icon icon-users"></span>
							<h2>Volunteer</h2>
							<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
						</div><!-- col-lg-4 -->	
						
						<div class="col-lg-4 callout">
							<span class="icon icon-gift"></span>
							<h2>Donate</h2>
							<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
						</div><!-- col-lg-4 -->	
					</div><!-- row -->
				</div><!-- whitewrap -->
			</div><!-- row -->
		</div><!-- container -->
		</div><!--get-involved-->
		 
			<div >
				<?php the_block("Jordan"); ?>	
			</div> 
			<div>
				<?php the_block("Contact"); ?>	
			</div> 
			<div>
				<?php the_block("Partners"); ?>	
			</div> 

				
				
				
			</div><!-- row -->
		</div><!-- container -->
		

		
<?php get_footer(); ?>