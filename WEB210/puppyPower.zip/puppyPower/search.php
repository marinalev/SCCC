<?php get_header(); ?>
	<div class="container blog-content">

		<?php if (have_posts()) : while (have_posts()) : the_post(); ?>

		
			<div class="col-lg-8">
				
					<h2><?php echo "Search results for " . get_search_query(); ?></h2>
					
					<?php the_content(); ?>

					
				
			</div>

		
	
		<?php endwhile; ?>


		<?php else : ?>

			<h2>Not Found</h2>
			 <p><?php get_search_form(); ?></p>

		<?php endif; ?>
			
			<?php get_sidebar("right"); ?>
		 
	</div><!--end container-->
<?php get_footer(); ?>